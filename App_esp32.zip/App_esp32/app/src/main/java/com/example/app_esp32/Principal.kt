package com.example.app_esp32

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.addCallback
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Principal : AppCompatActivity() {

    private lateinit var txtusu: EditText
    private lateinit var txtcon: EditText
    private lateinit var btnini: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_principal)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        txtusu = findViewById(R.id.txtusu)
        txtcon = findViewById(R.id.txtcon)
        btnini = findViewById(R.id.btnini)

        botonLogin()
        desactivarFlecha()


    }//Cierra el OnCreate.

    fun botonLogin(){
        btnini.setOnClickListener {
            if(txtusu.text.toString().trim().isEmpty()
                || txtcon.text.toString().trim().isEmpty()){

                Toast.makeText(
                    this@Principal,
                    "¡Complete Los Campos Faltantes!",
                    Toast.LENGTH_SHORT
                ).show()

            }else{

                var nom = txtusu.text.toString().trim().uppercase()
                var con = txtcon.text.toString().toInt()

                if(nom.equals("cgonzalez", ignoreCase = true) && con == 123){
                    var ema = nom + "@gmail.com".uppercase()
                    var tip = "Operador".uppercase()

                    var usu = Usuario(nom, ema,tip, con)

                    var intento = Intent(this@Principal, Menu::class.java)
                    intento.putExtra("usu", usu)
                    startActivity(intento)
                }else{
                    Toast.makeText(
                        this@Principal,
                        "¡Error de Usuario y/o Contraseña!",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }//Cierra el if/else inicial.
        }

    }//Cierra el botonLogin.

    fun desactivarFlecha(){
        onBackPressedDispatcher.addCallback(this){

        }
    }//Cierra la función desactivarFlecha.


} // Cierra la clase principal.