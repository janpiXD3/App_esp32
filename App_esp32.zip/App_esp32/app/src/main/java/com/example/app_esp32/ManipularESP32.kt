package com.example.app_esp32

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.addCallback
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class ManipularESP32 : AppCompatActivity() {

    private lateinit var tvusumanipular: TextView
    private lateinit var btnon: Button
    private lateinit var btnoff: Button
    private lateinit var btnvolman: Button

    private var usu: Usuario? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_manipular_esp32)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        tvusumanipular = findViewById(R.id.tvusumanipular)
        btnon = findViewById(R.id.btnon)
        btnoff = findViewById(R.id.btnoff)
        btnvolman = findViewById(R.id.btnvolman)

        usu = intent.getParcelableExtra("usu", Usuario::class.java)

        tvusumanipular.setText("Bienvenido Usuario :" + usu?.nombre)

        volver()
        desactivarFlecha()

    }//Cierra el OnCreate.


    fun volver(){

        btnvolman.setOnClickListener {
            var intent = Intent(this@ManipularESP32, Menu::class.java)
            intent.putExtra("usu", usu)
            startActivity(intent)
        }
    }//Cierra la función volver.


    fun desactivarFlecha(){
        onBackPressedDispatcher.addCallback(this){

        }
    }//Cierra la función desactivarFlecha.

}